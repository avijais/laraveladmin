-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2017 at 09:09 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `terms_condition` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `terms_condition`, `created_at`, `updated_at`) VALUES
(1, 'Avinash Jaiswal', 'avinash@email.com', '123', NULL, 1, NULL, NULL),
(2, 'Avi', 'avi@email.com', '123', NULL, 1, '2017-01-28 15:01:13', '2017-01-28 15:01:13'),
(3, 'suman', 'suman@email.com', '123', NULL, 0, '2017-01-28 15:06:02', '2017-01-28 15:06:02'),
(4, 'Aman', 'aman@email.com', '123', NULL, 0, '2017-01-28 15:44:44', '2017-01-28 15:44:44'),
(5, 'Chottu', 'chottu@email.com', '123', NULL, 0, '2017-01-28 15:46:24', '2017-01-28 15:46:24'),
(6, 'Dev', 'dev@email.com', '123', NULL, 0, '2017-01-28 15:50:02', '2017-01-28 15:50:02'),
(7, 'Ajit', 'ajit@email.com', '123', NULL, 0, '2017-01-29 14:20:53', '2017-01-29 14:20:53'),
(8, 'Sujit', 'sujit@email.com', '123', NULL, 0, '2017-01-29 14:23:25', '2017-01-29 14:23:25'),
(10, 'sanjay', 'sanjay@email.com', '123', NULL, 1, '2017-01-29 14:27:17', '2017-01-29 14:27:17'),
(11, 'sona', 'sona@email.com', '123', NULL, 1, '2017-01-29 14:29:19', '2017-01-29 14:29:19'),
(12, 'Mona', 'mona@email.co', '123', NULL, 1, '2017-01-29 14:32:13', '2017-01-29 14:32:13'),
(13, 'Raj', 'raj@email.com', '123', NULL, 1, '2017-01-29 14:35:06', '2017-01-29 14:35:06'),
(14, 'Deepak', 'deepak@email.com', '123', NULL, 1, '2017-01-29 14:37:34', '2017-01-29 14:37:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
 ADD KEY `password_resets_email_index` (`email`), ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
